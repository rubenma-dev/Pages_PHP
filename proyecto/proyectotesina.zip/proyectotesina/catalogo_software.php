<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.98.0">
    <title>Catalogo de Software</title>

     <!-- CSS only -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
     <!-- JavaScript Bundle with Popper -->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/carousel/">

     <!-- Cdn: Incluya la hoja de estilo de fuentes de iconos, en su sitio web o a través de CSS, 
    desde nuestra CDN y comience en segundos. Consulte los documentos de fuente de icono para ver ejemplos.<head>@import -->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    
    

<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="./css/carousel.css" rel="stylesheet">
<link rel="stylesheet" href="./css/estilos.css">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
    <link rel="stylesheet" href="estilos.css">
  </head>
  <body>


  <header class="site-header sticky-top py-1">

<!--	--------------->
<div class="container">
<div class="btn-menu">
  <label for="btn-menu">☰</label>
</div>
<input type="checkbox" id="btn-menu">
<div class="container-menu">
<div class="cont-menu">
  <nav>
    <a href="./index.php">Iniciar Sesion</a>
    <a href="./contactenos.php">Contactenos</a>
    <a href="./link_social.php">Facebook</a>
    <a href="./link_social_2.php">Whatsapp</a>
    <a href="./link_social_3.php">Instagram</a>
    <a href="./link_social_4.php">Twitter</a>
  </nav>
  <label for="btn-menu">✖️</label>
</div>
</div>
</body>


<nav class="container d-flex flex-column flex-md-row justify-content-between">
  <a class="py-2" href="#" aria-label="Product">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="d-block mx-auto" role="img" viewBox="0 0 24 24"><title>Product</title><circle cx="12" cy="12" r="10"/><path d="M14.31 8l5.74 9.94M9.69 8h11.48M7.38 12l5.74-9.94M9.69 16L3.95 6.06M14.31 16H2.83m13.79-4l-5.74 9.94"/></svg>
  </a>
  <a class="py-2 d-none d-md-inline-block" href="./index_2.php">Inicio</a>
  <div class="dropdown">
<button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
  Servicios
</button>
<ul class="dropdown-menu">
  <li><a class="dropdown-item" href="./firmware.php">Soporte en Actualizacion y Reparacion de Firmware</a></li>
  <li><a class="dropdown-item" href="./frp.php">Soporte en Proteccion de restauracion de Fabrica (FRP)</a></li>
  <li><a class="dropdown-item" href="./IMEI.php">Reparacion de IMEI</a></li>
  <li><a class="dropdown-item" href="./bluetooth.php">Reparacion de Bluetooth</a></li>
  <li><a class="dropdown-item" href="./wifi.php">Reparacion de WIFI</a></li>
  <li><a class="dropdown-item" href="./liberacion.php">Liberacion</a></li>
  <li><a class="dropdown-item" href="./sistema_operativo.php">Instalacion de Sistemas operativos (OS) para tu PC o Notebook</a></li>
  <li><a class="dropdown-item" href="./desbloqueo_pc.php">Desbloqueo de PC</a></li>
</ul>
</div>
  <a class="py-2 d-none d-md-inline-block" href="./funciones.php">Funciones</a>
  <a class="py-2 d-none d-md-inline-block" href="./empresa.php">Empresa</a>
  <a class="py-2 d-none d-md-inline-block" href="./soporte.php">Soporte</a>
  <a class="py-2 d-none d-md-inline-block" href="./precios.php">Precios</a>
  <a class="py-2 d-none d-md-inline-block" href="./atencion_cliente.php">Atencion al Cliente</a>
</nav>
</header>

    

<main>




  <!-- Marketing messaging and featurettes
  ================================================== -->
  <!-- Wrap the rest of the page in another container to center all the content. -->

  <div class="container marketing">
    <!-- START THE FEATURETTES -->

    <hr class="featurette-divider">

    <div class="row featurette">
      <div class="col-md-7">
        <h2 class="featurette-heading fw-normal lh-1">Reparacion de Software<span class="text-muted"></span></h2>
        <p class="lead">Pulsa aqui para ver detalles y especificaciones.</p>
        <p><a class="btn btn-lg btn-primary" href="./reparacion_software.php">Hecha un vistazo</a></p>
      </div>
      <div class="col-md-5">
        <img src="./image/image148.jpg" class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false">

      </div>
    </div>

    <hr class="featurette-divider">
    

    <!-- /END THE FEATURETTES -->

  </div><!-- /.container -->


  <!-- FOOTER -->
  <footer class="container">
  <p class="float-end"><a href="./index_2.php">Back to top</a></p>
    <div class="row">
        <div class="col-12 col-md">
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://youtube.com" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/youtube.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://www.facebook.com" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/facebook.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://wa.me/c/595976594987" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/whatsapp.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://www.instagram.com" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/instagram.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="./index.php" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/android2.svg" alt="Bootstrap" width="32" height="32">
          </a>
        </div>
        <div class="col-6 col-md">
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./cosas_geniales.php">Cosas Geniales</a></li>
            <li><a class="link-secondary" href="./funcion_aleatoria.php">Funcion Aleatoria</a></li>
            <li><a class="link-secondary" href="./funcion_equipo.php">Funcion del equipo</a></li>
            <li><a class="link-secondary" href="./cosas_desarrolladores.php">Cosas para desarrolladores</a></li>
            <li><a class="link-secondary" href="./otros.php">Otros</a></li>
            <li><a class="link-secondary" href="./ultima_vez.php">Ultima Vez</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Recursos</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./nombre_recurso.php">Nombre del recurso</a></li>
            <li><a class="link-secondary" href="./recurso.php">Recurso</a></li>
            <li><a class="link-secondary" href="./otro_recurso.php">Otro recurso</a></li>
            <li><a class="link-secondary" href="./recurso_final.php">Recurso final</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Recursos</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./negocios.php">Negocios</a></li>
            <li><a class="link-secondary" href="./patrocinadores.php">Patrocinadores</a></li>
            <li><a class="link-secondary" href="./ubicaciones.php">Ubicaciones</a></li>
            <li><a class="link-secondary" href="./juegos.php">Juegos</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Acerca de</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./equipo.php">Equipo</a></li>
            <li><a class="link-secondary" href="./locations.php">Locations</a></li>
            <li><a class="link-secondary" href="./quienes_somos.php">¿Quienes Somos?</a></li>
            <li><a class="link-secondary" href="./terminos_compra.php">Terminos de Compra</a></li>
          </ul>
        </div>
      </div>
  </footer>
  </footer>
</div>
    
</main>


    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

      
  </body>
</html>
