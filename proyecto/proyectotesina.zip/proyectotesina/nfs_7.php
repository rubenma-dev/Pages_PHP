<!doctype html>
<html lang="en" class="h-100">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.98.0">
    <title>Need for Speed: Carbon</title>

    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/sign-in/">
    

    <link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/cover/">

    

    

<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="./css/cover_juegos.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="cover_juegos.css" rel="stylesheet">
  </head>
  <body class="d-flex h-100 text-center text-white bg-dark">
    
<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
  <header class="mb-auto">
    <div>
      <h3 class="float-md-start mb-0">Juegos</h3>
      <nav class="nav nav-masthead justify-content-center float-md-end">
      </nav>
    </div>
  </header>

  <main class="px-3">
    <h1>Need for Speed: Carbon</h1>
    <img src="./image/image19.jpg" class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false">
    <p class="lead">Lo que empieza en la ciudad termina en los cañones, ya que te sumerge en las carreras callejeras más peligrosas y llenas de adrenalina del mundo. Elige estratégicamente a los miembros de tu equipo y utiliza sus habilidades en la pista y en el garaje para ayudarte a ganar carreras y personalizar tus vehículos. Compite por el control de la ciudad eliminando a los equipos competidores en sus propios terrenos, y luego vence a los líderes de sus tripulaciones en carreras a vida o muerte.
    Únete a las divisiones de vehículos Tuner, American Muscle o Exotic y demuestra quién fabrica el mejor juego de ruedas de una vez por todas. Gracias a un novedoso modelo de física, cada clase se maneja y conduce de forma diferente. Las nuevas clases de carreras Canyon Duel y Drift son la prueba definitiva de habilidad y nervio, en la que un giro en falso te costará más que la propia carrera.</p>
    <img src="./image/image75.jpg" class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false">
    <img src="./image/image76.jpg" class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false">
    <img src="./image/image77.jpg" class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false">
    <p class="lead">Requisitos del Sistema.</p>
    <p class="lead">Sistemas Operativos: Windows 10 / 8 / 7 / XP
        Procesador: 1.7 GHz
        Memoria: 512 MB de RAM
        Tarjeta Gráfica: 64 MB de VRAM
        Disco Duro: 10 GB de espacio libre</p>
    <p class="lead">
      <a href="#" class="btn btn-lg btn-secondary fw-bold border-white bg-white">Compra ya</a>
    </p>
  </main>

  <footer class="mt-auto text-white-50">
  <p class="float-end"><a href="./index_2.php">Back to top</a></p>
    <div class="row">
        <div class="col-12 col-md">
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://youtube.com" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/youtube.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://www.facebook.com" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/facebook.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://wa.me/c/595976594987" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/whatsapp.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://www.instagram.com" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/instagram.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="./index.php" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/android2.svg" alt="Bootstrap" width="32" height="32">
          </a>
        </div>
        <div class="col-6 col-md">
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./cosas_geniales.php">Cosas Geniales</a></li>
            <li><a class="link-secondary" href="./funcion_aleatoria.php">Funcion Aleatoria</a></li>
            <li><a class="link-secondary" href="./funcion_equipo.php">Funcion del equipo</a></li>
            <li><a class="link-secondary" href="./cosas_desarrolladores.php">Cosas para desarrolladores</a></li>
            <li><a class="link-secondary" href="./otros.php">Otros</a></li>
            <li><a class="link-secondary" href="./ultima_vez.php">Ultima Vez</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Recursos</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./nombre_recurso.php">Nombre del recurso</a></li>
            <li><a class="link-secondary" href="./recurso.php">Recurso</a></li>
            <li><a class="link-secondary" href="./otro_recurso.php">Otro recurso</a></li>
            <li><a class="link-secondary" href="./recurso_final.php">Recurso final</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Recursos</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./negocios.php">Negocios</a></li>
            <li><a class="link-secondary" href="./patrocinadores.php">Patrocinadores</a></li>
            <li><a class="link-secondary" href="./ubicaciones.php">Ubicaciones</a></li>
            <li><a class="link-secondary" href="./juegos.php">Juegos</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Acerca de</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./equipo.php">Equipo</a></li>
            <li><a class="link-secondary" href="./locations.php">Locations</a></li>
            <li><a class="link-secondary" href="./quienes_somos.php">¿Quienes Somos?</a></li>
            <li><a class="link-secondary" href="./terminos_compra.php">Terminos de Compra</a></li>
          </ul>
        </div>
      </div>
  </footer>
  </footer>
</div>
    



    
  </body>
</html>
