<!doctype html>
<html lang="en" class="h-100">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.98.0">
    <title>Sanitarium</title>

    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/sign-in/">
    

    <link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/cover/">

    

    

<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="./css/cover_juegos.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="cover_juegos.css" rel="stylesheet">
  </head>
  <body class="d-flex h-100 text-center text-white bg-dark">
    
<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
  <header class="mb-auto">
    <div>
      <h3 class="float-md-start mb-0">Juegos</h3>
      <nav class="nav nav-masthead justify-content-center float-md-end">
      </nav>
    </div>
  </header>

  <main class="px-3">
    <h1>Sanitarium</h1>
    <img src="./image/image42.jpg" class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false">
    <p class="lead">Encarnas a un amnésico sumido en una realidad macabra y verdaderamente aterradora. Tras un accidente de tráfico, te despiertas y te encuentras en una institución con la cabeza cubierta de vendas, en lugar de en un hospital. ¿Qué demonios soy? ¿Qué hago exactamente aquí? ¿Cómo puedo escapar? Son muchas las preguntas que te atormentan, al igual que los numerosos enigmas que tendrás que responder durante esta experiencia envolvente y absorbente.
    Es una obra maestra apropiada para los novatos del point-and-click, los profesionales y cualquiera que aprecie las historias intrigantes y los juegos de terror, con un escenario profundo y complejo ambientado en un entorno intenso en el que una línea muy fina divide la razón de la locura. Ha sido recientemente nombrado uno de los videojuegos más terroríficos de todos los tiempos.</p>
    <img src="./image/image132.jpg" class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false">
    <img src="./image/image133.jpg" class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false">
    <img src="./image/image134.jpg" class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false">
    <p class="lead">Requisitos del Sistema.</p>
    <p class="lead">Sistemas Operativos: Windows 10 / 8 / 7 / XP
        Procesador: 2.4Ghz
        Memoria: 1 GB de RAM
        Tarjeta Gráfica: Intel HD
        Disco Duro: 100 MB de espacio libre</p>
    <p class="lead">
      <a href="#" class="btn btn-lg btn-secondary fw-bold border-white bg-white">Compra ya</a>
    </p>
  </main>

  <footer class="mt-auto text-white-50">
  <p class="float-end"><a href="./index_2.php">Back to top</a></p>
    <div class="row">
        <div class="col-12 col-md">
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://youtube.com" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/youtube.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://www.facebook.com" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/facebook.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://wa.me/c/595976594987" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/whatsapp.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://www.instagram.com" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/instagram.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="./index.php" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/android2.svg" alt="Bootstrap" width="32" height="32">
          </a>
        </div>
        <div class="col-6 col-md">
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./cosas_geniales.php">Cosas Geniales</a></li>
            <li><a class="link-secondary" href="./funcion_aleatoria.php">Funcion Aleatoria</a></li>
            <li><a class="link-secondary" href="./funcion_equipo.php">Funcion del equipo</a></li>
            <li><a class="link-secondary" href="./cosas_desarrolladores.php">Cosas para desarrolladores</a></li>
            <li><a class="link-secondary" href="./otros.php">Otros</a></li>
            <li><a class="link-secondary" href="./ultima_vez.php">Ultima Vez</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Recursos</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./nombre_recurso.php">Nombre del recurso</a></li>
            <li><a class="link-secondary" href="./recurso.php">Recurso</a></li>
            <li><a class="link-secondary" href="./otro_recurso.php">Otro recurso</a></li>
            <li><a class="link-secondary" href="./recurso_final.php">Recurso final</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Recursos</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./negocios.php">Negocios</a></li>
            <li><a class="link-secondary" href="./patrocinadores.php">Patrocinadores</a></li>
            <li><a class="link-secondary" href="./ubicaciones.php">Ubicaciones</a></li>
            <li><a class="link-secondary" href="./juegos.php">Juegos</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Acerca de</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./equipo.php">Equipo</a></li>
            <li><a class="link-secondary" href="./locations.php">Locations</a></li>
            <li><a class="link-secondary" href="./quienes_somos.php">¿Quienes Somos?</a></li>
            <li><a class="link-secondary" href="./terminos_compra.php">Terminos de Compra</a></li>
          </ul>
        </div>
      </div>
  </footer>
  </footer>
</div>
    

    
  </body>
</html>
