<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.98.0">
    <title>Productos</title>

     <!-- CSS only -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
     <!-- JavaScript Bundle with Popper -->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/carousel/">

     <!-- Cdn: Incluya la hoja de estilo de fuentes de iconos, en su sitio web o a través de CSS, 
    desde nuestra CDN y comience en segundos. Consulte los documentos de fuente de icono para ver ejemplos.<head>@import -->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    
    

<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="./css/carousel.css" rel="stylesheet">
<link rel="stylesheet" href="./css/estilos.css">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="carousel.css" rel="stylesheet">
    <link rel="stylesheet" href="estilos.css">
    <link rel="stylesheet" href="bootstrap-icons.css">
  </head>
  <body>


    <header class="site-header sticky-top py-1">

      <!--	--------------->
    <div class="container">
      <div class="btn-menu">
        <label for="btn-menu">☰</label>
      </div>
    <input type="checkbox" id="btn-menu">
    <div class="container-menu">
      <div class="cont-menu">
        <nav>
          <a href="./index.php">Iniciar Sesion</a>
          <a href="./contactenos.php">Contactenos</a>
          <a href="./link_social.php">Facebook</a>
          <a href="./link_social_2.php">Whatsapp</a>
          <a href="./link_social_3.php">Instagram</a>
          <a href="./link_social_4.php">Twitter</a>
        </nav>
        <label for="btn-menu">✖️</label>
      </div>
    </div>
    </body>
    
    
      <nav class="container d-flex flex-column flex-md-row justify-content-between">
        <a class="py-2" href="#" aria-label="Product">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="d-block mx-auto" role="img" viewBox="0 0 24 24"><title>Product</title><circle cx="12" cy="12" r="10"/><path d="M14.31 8l5.74 9.94M9.69 8h11.48M7.38 12l5.74-9.94M9.69 16L3.95 6.06M14.31 16H2.83m13.79-4l-5.74 9.94"/></svg>
        </a>
        <a class="py-2 d-none d-md-inline-block" href="./index_2.php">Inicio</a>
        <div class="dropdown">
      <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
        Servicios
      </button>
      <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="./firmware.php">Soporte en Actualizacion y Reparacion de Firmware</a></li>
        <li><a class="dropdown-item" href="./frp.php">Soporte en Proteccion de restauracion de Fabrica (FRP)</a></li>
        <li><a class="dropdown-item" href="./IMEI.php">Reparacion de IMEI</a></li>
        <li><a class="dropdown-item" href="./bluetooth.php">Reparacion de Bluetooth</a></li>
        <li><a class="dropdown-item" href="./wifi.php">Reparacion de WIFI</a></li>
        <li><a class="dropdown-item" href="./liberacion.php">Liberacion</a></li>
        <li><a class="dropdown-item" href="./sistema_operativo.php">Instalacion de Sistemas operativos (OS) para tu PC o Notebook</a></li>
        <li><a class="dropdown-item" href="./desbloqueo_pc.php">Desbloqueo de PC</a></li>
      </ul>
    </div>
        <a class="py-2 d-none d-md-inline-block" href="./funciones.php">Funciones</a>
        <a class="py-2 d-none d-md-inline-block" href="./empresa.php">Empresa</a>
        <a class="py-2 d-none d-md-inline-block" href="./soporte.php">Soporte</a>
        <a class="py-2 d-none d-md-inline-block" href="./precios.php">Precios</a>
        <a class="py-2 d-none d-md-inline-block" href="./atencion_cliente.php">Atencion al Cliente</a>
      </nav>
    </header>
    

<main>


  <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="./image/image147.jpg" class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#777"/>
        <div class="container">
          <div class="carousel-caption text-black">
            <h1>Servicios de Firmware</h1>
            <p>Haz click aqui para poder ver mas y que modelos soportamos este servicio.</p>
            <p><a class="btn btn-lg btn-primary" href="./firmware.php">Haz click aqui</a></p>
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <img src="./image/image148.jpg" class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#777"/>
        <div class="container">
          <div class="carousel-caption text-black">
            <h1>Desbloqueo FRP</h1> 
            <p>Hecha un vistazo a nuestro catalogo y averigua que modelos nos dedicamos a realizar este servicio.</p>
            <p><a class="btn btn-lg btn-primary" href="./frp.php">Haz click aqui</a></p>
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <img src="./image/image7.png" class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#777"/>
        <div class="container">
          <div class="carousel-caption text-black text-end">
            <h1>Software para PC</h1>
            <p>Todo lo que tenga que ver en la reparacion e instalacion de sistemas operativos esta aqui. Hecha 
              un vistazo en la descripcion y que servicios tenemos a tu disposicion.</p>
            <p><a class="btn btn-lg btn-primary" href="./desbloqueo_pc.php">Hecha un vistazo</a></p>
          </div>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>


  <!-- Marketing messaging and featurettes
  ================================================== -->
  <!-- Wrap the rest of the page in another container to center all the content. -->

  <div class="container marketing">

    <!-- Three columns of text below the carousel -->
    <div class="row">
      <div class="col-lg-4">
        <img src="./image/image1.jpg" class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 140x140" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em"></text></svg>

        <h2 class="fw-normal">Monitores</h2>
        <p>Tenemos una gran variedad de monitores que estan dirigidos para varios tipos de utilidades.</p>
        <p><a class="btn btn-secondary" href="./viewzonic_XG.php">Mas detalles &raquo;</a></p>
      </div><!-- /.col-lg-4 -->
      <div class="col-lg-4">
        <img src="./image/image8.jpg" class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 140x140" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em"></text></svg>
        <h2 class="fw-normal">Notebook Gamer</h2>
        <p>Tenemos todas las notebooks de tipo gamer para que puedas elegir la que mas te guste segun su especificacion</p>
        <p><a class="btn btn-secondary" href="./notebook_gamer.php">Mas detalles &raquo;</a></p>
      </div><!-- /.col-lg-4 -->
      <div class="col-lg-4">
        <img src="./image/image27.jpg" class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 140x140" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em"></text></svg>

        <h2 class="fw-normal">Combo PC</h2>
        <p>Para los jugadores tradicionales de PC de mesa. Tenemos pensado combos de hardware que estan dirijidas dependiendo de que tipo procesador estes buscando</p>
        <p><a class="btn btn-secondary" href="./combo_PC.php">Mas detalles &raquo;</a></p>
      </div><!-- /.col-lg-4 -->
    </div><!-- /.row -->


    <!-- START THE FEATURETTES -->

    <hr class="featurette-divider">

    <div class="row featurette">
      <div class="col-md-7">
        <h2 class="featurette-heading fw-normal lh-1">Monitor de alta definicion. <span class="text-muted">Pensado para jugadores profesionales con altas exigencias en redimiento</span></h2>
        <p class="lead">Pulsa aqui y veras la variedad de nuestros monitores.</p>
        <p><a class="btn btn-lg btn-primary" href="./viewzonic_XG.php">Hecha un vistazo</a></p>
      </div>
      <div class="col-md-5">
        <img src="./image/image1.jpg" class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false">

      </div>
    </div>

    <hr class="featurette-divider">

    <div class="row featurette">
      <div class="col-md-7 order-md-2">
        <h2 class="featurette-heading fw-normal lh-1">Notebook de Ofimatica <span class="text-muted">Pensado para profesores y estudiantes que estan en carreras en donde la utilizacion de un Notebook es indispensable.</span></h2>
        <p class="lead">Pulsa aqui para poder acceder a ella y a la variedad de equipos que tenemos para ofrecerte.</p>
        <p><a class="btn btn-lg btn-primary" href="./notebook_ofimatica.php">Hecha un vistazo</a></p>
      </div>
      <div class="col-md-5 order-md-1">
        <img src="./image/image2.jpg" class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false">

      </div>
    </div>

    <hr class="featurette-divider">

    <div class="row featurette">
      <div class="col-md-7">
        <h2 class="featurette-heading fw-normal lh-1">Notebook de Alto rendimiento <span class="text-muted">Pensados para personas que usan software que utilizan muchos requisitos del sistema como Autocad o para jugadores gamers que quieren pasar el tiempo y llevar sus equipos en donde quieran</span></h2>
        <p class="lead">Pulsa aqui y ve las distintas variedaddes que disponemos y los equipos que tenemos y que son pensados para ti.</p>
        <p><a class="btn btn-lg btn-primary" href="./notebook_gamer.php">Hecha un vistazo</a></p>
      </div>
      <div class="col-md-5">
        <img src="./image/image3.jpg" class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false">

      </div>
    </div>

    <hr class="featurette-divider">

    <div class="row featurette">
      <div class="col-md-7 order-md-2">
        <h2 class="featurette-heading fw-normal lh-1">Esta dirijido a un publico que necesita un equipo con los mejores rendimientos y mejores recursos de hardware.</span></h2>
        <p class="lead">Pulsa aqui para poder acceder a ella y a la variedad de equipos que tenemos para ofrecerte.</p>
        <p><a class="btn btn-lg btn-primary" href="./notebook_i7.php">Hecha un vistazo</a></p>
      </div>
      <div class="col-md-5 order-md-1">
        <img src="./image/image4.jpg" class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" width="500" height="500" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 500x500" preserveAspectRatio="xMidYMid slice" focusable="false">

      </div>
    </div>

    <hr class="featurette-divider">

    

    <!-- /END THE FEATURETTES -->

  </div><!-- /.container -->


  <!-- FOOTER -->
  <footer class="container">
    <p class="float-end"><a href="./index_2.php">Back to top</a></p>
    <div class="row">
        <div class="col-12 col-md">
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://youtube.com" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/youtube.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://www.facebook.com" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/facebook.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://wa.me/c/595976594987" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/whatsapp.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="https://www.instagram.com" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/instagram.svg" alt="Bootstrap" width="32" height="32">
          </a>
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="./index.php" aria-label="Bootstrap" _mstaria-label="138918">
            <img src="./iconos/android2.svg" alt="Bootstrap" width="32" height="32">
          </a>
        </div>
        <div class="col-6 col-md">
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./cosas_geniales.php">Cosas Geniales</a></li>
            <li><a class="link-secondary" href="./funcion_aleatoria.php">Funcion Aleatoria</a></li>
            <li><a class="link-secondary" href="./funcion_equipo.php">Funcion del equipo</a></li>
            <li><a class="link-secondary" href="./cosas_desarrolladores.php">Cosas para desarrolladores</a></li>
            <li><a class="link-secondary" href="./otros.php">Otros</a></li>
            <li><a class="link-secondary" href="./ultima_vez.php">Ultima Vez</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Recursos</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./nombre_recurso.php">Nombre del recurso</a></li>
            <li><a class="link-secondary" href="./recurso.php">Recurso</a></li>
            <li><a class="link-secondary" href="./otro_recurso.php">Otro recurso</a></li>
            <li><a class="link-secondary" href="./recurso_final.php">Recurso final</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Recursos</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./negocios.php">Negocios</a></li>
            <li><a class="link-secondary" href="./patrocinadores.php">Patrocinadores</a></li>
            <li><a class="link-secondary" href="./ubicaciones.php">Ubicaciones</a></li>
            <li><a class="link-secondary" href="./juegos.php">Juegos</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Acerca de</h5>
          <ul class="list-unstyled text-small">
            <li><a class="link-secondary" href="./equipo.php">Equipo</a></li>
            <li><a class="link-secondary" href="./locations.php">Locations</a></li>
            <li><a class="link-secondary" href="./quienes_somos.php">¿Quienes Somos?</a></li>
            <li><a class="link-secondary" href="./terminos_compra.php">Terminos de Compra</a></li>
          </ul>
        </div>
      </div>
  </footer>
  </footer>
</div>
</main>


    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

      
  </body>
</html>
