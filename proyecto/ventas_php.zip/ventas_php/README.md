# ventas-php
Pequeño sistema de ventas en php y mysql
